"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import Link from "next/link";
import { Shield, Car } from "lucide-react";

const formSchema = z.object({
  username: z.string().min(2, "Username must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  mobileNumber: z.string().regex(/^[0-9]{10}$/, "Invalid mobile number"),
  role: z.enum(["user", "mechanic", "petrolpump", "hospital"]),
  carCompany: z.string().optional(),
  carModel: z.string().optional(),
});

const carCompanies = {
  Toyota: ["Camry", "Corolla", "RAV4", "Highlander"],
  Honda: ["Civic", "Accord", "CR-V", "Pilot"],
  Ford: ["F-150", "Mustang", "Explorer", "Escape"],
  BMW: ["3 Series", "5 Series", "X3", "X5"],
  Mercedes: ["C-Class", "E-Class", "GLC", "GLE"],
};

export default function SignUpPage() {
  const [step, setStep] = useState(1);
  const [otp, setOtp] = useState("");
  const [showOtpInput, setShowOtpInput] = useState(false);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      username: "",
      email: "",
      mobileNumber: "",
      role: "user",
      carCompany: "",
      carModel: "",
    },
  });

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    if (step === 1) {
      // Send OTP
      setShowOtpInput(true);
      toast({
        title: "OTP Sent",
        description: "Please check your mobile number for OTP",
      });
      return;
    }

    if (step === 2 && otp === "123456") { // Replace with actual OTP verification
      if (values.role === "user") {
        setStep(3);
      } else {
        // Handle non-user role signup
        toast({
          title: "Success",
          description: "Account created successfully!",
        });
      }
    } else {
      toast({
        title: "Error",
        description: "Invalid OTP",
        variant: "destructive",
      });
    }
  };

  const renderStepIndicator = () => {
    const totalSteps = form.watch("role") === "user" ? 3 : 2;
    return (
      <div className="flex items-center justify-center space-x-2 mb-6">
        {Array.from({ length: totalSteps }).map((_, index) => (
          <div
            key={index}
            className={`w-2 h-2 rounded-full ${
              index + 1 === step ? "bg-primary" : "bg-gray-300"
            }`}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b shadow-sm">
        <div className="container flex items-center justify-between h-16 px-4">
          <div className="flex items-center space-x-2">
            <Shield className="w-8 h-8 text-primary" />
            <h1 className="text-xl font-bold">RoadGuard</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold text-center">Create Account</CardTitle>
            {renderStepIndicator()}
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                {step === 1 && (
                  <>
                    <FormField
                      control={form.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <FormControl>
                            <Input placeholder="Choose a username" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="mobileNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Mobile Number</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your mobile number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="role"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Role</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select your role" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="user">User</SelectItem>
                              <SelectItem value="mechanic">Mechanic</SelectItem>
                              <SelectItem value="petrolpump">Petrol Pump</SelectItem>
                              <SelectItem value="hospital">Hospital</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </>
                )}

                {step === 2 && showOtpInput && (
                  <FormItem>
                    <FormLabel>Enter OTP</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Enter the OTP sent to your mobile"
                        value={otp}
                        onChange={(e) => setOtp(e.target.value)}
                      />
                    </FormControl>
                  </FormItem>
                )}

                {step === 3 && form.watch("role") === "user" && (
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2 text-primary mb-2">
                      <Car className="w-5 h-5" />
                      <h3 className="font-medium">Vehicle Information</h3>
                    </div>
                    <FormField
                      control={form.control}
                      name="carCompany"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Car Company</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select car company" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {Object.keys(carCompanies).map((company) => (
                                <SelectItem key={company} value={company}>
                                  {company}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    {form.watch("carCompany") && (
                      <FormField
                        control={form.control}
                        name="carModel"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Car Model</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select car model" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {carCompanies[form.watch("carCompany") as keyof typeof carCompanies].map(
                                  (model) => (
                                    <SelectItem key={model} value={model}>
                                      {model}
                                    </SelectItem>
                                  )
                                )}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}
                  </div>
                )}

                <Button type="submit" className="w-full">
                  {step === 1 ? "Send OTP" : step === 2 ? "Verify OTP" : "Create Account"}
                </Button>

                <div className="text-center text-sm text-muted-foreground">
                  Already have an account?{" "}
                  <Link href="/auth/signin" className="text-primary hover:underline font-medium">
                    Sign in
                  </Link>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </main>
    </div>
  );
} 