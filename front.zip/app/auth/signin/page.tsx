"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import Link from "next/link";
import { Shield } from "lucide-react";
import { useRouter } from "next/navigation";
import { mockUsers } from "@/lib/mock-data";

const formSchema = z.object({
  mobileNumber: z.string().regex(/^[0-9]{10}$/, "Invalid mobile number"),
});

export default function SignInPage() {
  const [otp, setOtp] = useState("");
  const [showOtpInput, setShowOtpInput] = useState(false);
  const { toast } = useToast();
  const router = useRouter();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      mobileNumber: "",
    },
  });

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    if (!showOtpInput) {
      // Check if user exists in mock data
      const user = mockUsers.find(user => user.mobileNumber === values.mobileNumber);
      if (!user) {
        toast({
          title: "Error",
          description: "User not found. Please sign up first.",
          variant: "destructive",
        });
        return;
      }
      // Send OTP
      setShowOtpInput(true);
      toast({
        title: "OTP Sent",
        description: "Please check your mobile number for OTP",
      });
      return;
    }

    if (otp === "123456") { // Replace with actual OTP verification
      toast({
        title: "Success",
        description: "Logged in successfully!",
      });
      // Store user data in localStorage for demo purposes
      const user = mockUsers.find(user => user.mobileNumber === form.getValues("mobileNumber"));
      if (user) {
        localStorage.setItem("user", JSON.stringify(user));
        // Redirect based on user role
        if (user.role === "mechanic") {
          router.push("/dashboard/mechanics");
        } else {
          router.push("/dashboard");
        }
        if (user.role === "petrolpump") {
            router.push("/dashboard/petrol-pump");
          }  
          if (user.role === "hospital") {
            router.push("/dashboard/hospital");
          } 

        
      }
    } else {
      toast({
        title: "Error",
        description: "Invalid OTP",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b shadow-sm">
        <div className="container flex items-center justify-between h-16 px-4">
          <div className="flex items-center space-x-2">
            <Shield className="w-8 h-8 text-primary" />
            <h1 className="text-xl font-bold">RoadGuard</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold text-center">Welcome Back</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="mobileNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Mobile Number</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter your mobile number" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {showOtpInput && (
                  <FormItem>
                    <FormLabel>Enter OTP</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Enter the OTP sent to your mobile"
                        value={otp}
                        onChange={(e) => setOtp(e.target.value)}
                      />
                    </FormControl>
                  </FormItem>
                )}

                <Button type="submit" className="w-full">
                  {showOtpInput ? "Verify OTP" : "Send OTP"}
                </Button>

                <div className="text-center text-sm text-muted-foreground">
                  Don't have an account?{" "}
                  <Link href="/auth/signup" className="text-primary hover:underline font-medium">
                    Sign up
                  </Link>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </main>
    </div>
  );
} 