"use client"

import type React from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Car,
  Settings,
  Bell,
  Clock,
  Calendar,
  CheckCircle,
  XCircle,
  MapPin,
  Phone,
  MessageSquare,
  Star,
  Wrench,
  PenToolIcon as Tool,
} from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"

export default function MechanicDashboard() {
  return (
    <div className="flex min-h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="hidden md:flex w-64 flex-col bg-white border-r">
        <div className="flex items-center h-16 px-6 border-b">
          <Car className="w-6 h-6 text-primary mr-2" />
          <h1 className="font-bold text-lg">Mechanic Portal</h1>
        </div>

        <div className="flex flex-col flex-1 p-4">
          <nav className="space-y-1">
            <Button variant="ghost" className="w-full justify-start">
              <Car className="mr-2 h-4 w-4" />
              Dashboard
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <Clock className="mr-2 h-4 w-4" />
              Active Requests
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <Calendar className="mr-2 h-4 w-4" />
              Schedule
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <CheckCircle className="mr-2 h-4 w-4" />
              Completed Jobs
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <Star className="mr-2 h-4 w-4" />
              Reviews
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <Settings className="mr-2 h-4 w-4" />
              Settings
            </Button>
          </nav>
        </div>

        <div className="p-4 border-t">
          <div className="flex items-center">
            <Avatar className="h-9 w-9 mr-2">
              <AvatarImage src="/placeholder.svg?height=36&width=36" alt="Avatar" />
              <AvatarFallback>MC</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium text-sm">Mike Carter</p>
              <p className="text-xs text-muted-foreground">Certified Mechanic</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1">
        {/* Header */}
        <header className="bg-white border-b h-16 flex items-center justify-between px-6">
          <div className="md:hidden">
            <Car className="w-6 h-6 text-primary" />
          </div>

          <div className="flex items-center ml-auto">
            <Button variant="ghost" size="icon">
              <Bell className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <MessageSquare className="h-5 w-5" />
            </Button>
            <Avatar className="h-8 w-8 ml-2">
              <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Avatar" />
              <AvatarFallback>MC</AvatarFallback>
            </Avatar>
          </div>
        </header>

        {/* Dashboard Content */}
        <main className="p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold">Mechanic Dashboard</h1>
              <p className="text-muted-foreground">Manage service requests and track your performance</p>
            </div>
            <div className="flex items-center mt-4 md:mt-0">
              <Badge variant="outline" className="bg-green-100 text-green-800 mr-2">
                Online
              </Badge>
              <Button variant="outline">Go Offline</Button>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-6">
            <StatsCard
              title="Today's Jobs"
              value="5"
              icon={<Wrench className="h-5 w-5" />}
              description="2 completed, 3 pending"
            />
            <StatsCard
              title="Response Rate"
              value="95%"
              icon={<Clock className="h-5 w-5" />}
              description="Above average"
            />
            <StatsCard
              title="Rating"
              value="4.8/5"
              icon={<Star className="h-5 w-5" />}
              description="Based on 124 reviews"
            />
            <StatsCard
              title="Earnings"
              value="$350"
              icon={<Tool className="h-5 w-5" />}
              description="Today's earnings"
            />
          </div>

          {/* Active Request */}
          <Card className="mb-6 border-l-4 border-l-blue-500">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Active Request</CardTitle>
                  <CardDescription>Currently assigned service request</CardDescription>
                </div>
                <Badge className="bg-blue-100 text-blue-800">In Progress</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row md:items-center justify-between">
                <div className="space-y-3">
                  <div className="flex items-start">
                    <Avatar className="h-10 w-10 mr-3">
                      <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Customer" />
                      <AvatarFallback>JS</AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-medium">John Smith</h3>
                      <p className="text-sm text-muted-foreground">Flat Tire • Toyota Camry</p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <MapPin className="h-5 w-5 mr-2 text-muted-foreground flex-shrink-0" />
                    <div>
                      <p className="text-sm">123 Main Street, Anytown</p>
                      <p className="text-xs text-muted-foreground">3.2 miles away • 15 min ETA</p>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline" className="flex items-center">
                      <Phone className="h-4 w-4 mr-1" />
                      Call
                    </Button>
                    <Button size="sm" variant="outline" className="flex items-center">
                      <MessageSquare className="h-4 w-4 mr-1" />
                      Message
                    </Button>
                    <Button size="sm" variant="outline" className="flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      Directions
                    </Button>
                  </div>
                </div>

                <div className="mt-4 md:mt-0 flex flex-col items-center">
                  <div className="text-center mb-2">
                    <p className="text-sm text-muted-foreground">Job Progress</p>
                    <div className="flex items-center justify-center">
                      <Clock className="h-4 w-4 mr-1 text-blue-500" />
                      <p className="text-sm font-medium">Started 25 mins ago</p>
                    </div>
                  </div>

                  <div className="w-full max-w-[200px]">
                    <Progress value={65} className="h-2" />
                    <div className="flex justify-between mt-1">
                      <span className="text-xs">Arrived</span>
                      <span className="text-xs">Working</span>
                      <span className="text-xs">Complete</span>
                    </div>
                  </div>

                  <Button className="mt-4">Mark as Complete</Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Pending Requests */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Pending Requests</CardTitle>
              <CardDescription>Nearby service requests you can accept</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="nearby">
                <TabsList className="mb-4">
                  <TabsTrigger value="nearby">Nearby</TabsTrigger>
                  <TabsTrigger value="urgent">Urgent</TabsTrigger>
                  <TabsTrigger value="all">All</TabsTrigger>
                </TabsList>

                <TabsContent value="nearby" className="space-y-4">
                  <RequestCard
                    name="Sarah Johnson"
                    issue="Dead Battery"
                    car="Honda Civic"
                    location="456 Oak Avenue, Anytown"
                    distance="1.8 miles"
                    time="5 mins ago"
                    urgent={false}
                  />
                  <RequestCard
                    name="Michael Brown"
                    issue="Engine Overheating"
                    car="Ford F-150"
                    location="789 Pine Road, Anytown"
                    distance="2.5 miles"
                    time="12 mins ago"
                    urgent={true}
                  />
                  <RequestCard
                    name="Emily Davis"
                    issue="Locked Out"
                    car="Nissan Altima"
                    location="101 Elm Street, Anytown"
                    distance="3.2 miles"
                    time="18 mins ago"
                    urgent={false}
                  />
                </TabsContent>

                <TabsContent value="urgent" className="space-y-4">
                  <RequestCard
                    name="Michael Brown"
                    issue="Engine Overheating"
                    car="Ford F-150"
                    location="789 Pine Road, Anytown"
                    distance="2.5 miles"
                    time="12 mins ago"
                    urgent={true}
                  />
                </TabsContent>

                <TabsContent value="all" className="space-y-4">
                  <RequestCard
                    name="Sarah Johnson"
                    issue="Dead Battery"
                    car="Honda Civic"
                    location="456 Oak Avenue, Anytown"
                    distance="1.8 miles"
                    time="5 mins ago"
                    urgent={false}
                  />
                  <RequestCard
                    name="Michael Brown"
                    issue="Engine Overheating"
                    car="Ford F-150"
                    location="789 Pine Road, Anytown"
                    distance="2.5 miles"
                    time="12 mins ago"
                    urgent={true}
                  />
                  <RequestCard
                    name="Emily Davis"
                    issue="Locked Out"
                    car="Nissan Altima"
                    location="101 Elm Street, Anytown"
                    distance="3.2 miles"
                    time="18 mins ago"
                    urgent={false}
                  />
                  <RequestCard
                    name="David Wilson"
                    issue="Flat Tire"
                    car="Chevrolet Malibu"
                    location="202 Maple Drive, Anytown"
                    distance="4.7 miles"
                    time="25 mins ago"
                    urgent={false}
                  />
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* Today's Schedule */}
          <Card>
            <CardHeader>
              <CardTitle>Today's Schedule</CardTitle>
              <CardDescription>Your upcoming appointments</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <ScheduleItem time="2:30 PM" name="John Smith" service="Flat Tire" status="in-progress" />
                <ScheduleItem time="4:00 PM" name="Lisa Anderson" service="Oil Change" status="scheduled" />
                <ScheduleItem time="5:30 PM" name="Robert Johnson" service="Battery Replacement" status="scheduled" />
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  )
}

function StatsCard({
  title,
  value,
  icon,
  description,
}: {
  title: string
  value: string
  icon: React.ReactNode
  description: string
}) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold">{value}</p>
          </div>
          <div className="p-2 rounded-full bg-primary/10">
            <div className="text-primary">{icon}</div>
          </div>
        </div>
        <p className="text-xs text-muted-foreground mt-2">{description}</p>
      </CardContent>
    </Card>
  )
}

function RequestCard({
  name,
  issue,
  car,
  location,
  distance,
  time,
  urgent,
}: {
  name: string
  issue: string
  car: string
  location: string
  distance: string
  time: string
  urgent: boolean
}) {
  return (
    <Card className={urgent ? "border-l-4 border-l-red-500" : ""}>
      <CardContent className="p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between">
          <div className="space-y-2">
            <div className="flex items-start">
              <Avatar className="h-10 w-10 mr-3">
                <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Customer" />
                <AvatarFallback>{name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <div className="flex items-center">
                  <h3 className="font-medium">{name}</h3>
                  {urgent && (
                    <Badge variant="outline" className="ml-2 bg-red-100 text-red-800">
                      Urgent
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">
                  {issue} • {car}
                </p>
              </div>
            </div>

            <div className="flex items-start">
              <MapPin className="h-5 w-5 mr-2 text-muted-foreground flex-shrink-0" />
              <div>
                <p className="text-sm">{location}</p>
                <p className="text-xs text-muted-foreground">
                  {distance} away • Requested {time}
                </p>
              </div>
            </div>
          </div>

          <div className="flex space-x-2 mt-4 md:mt-0">
            <Button size="sm" variant="outline" className="flex items-center">
              <XCircle className="h-4 w-4 mr-1" />
              Decline
            </Button>
            <Button size="sm" className="flex items-center">
              <CheckCircle className="h-4 w-4 mr-1" />
              Accept
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function ScheduleItem({
  time,
  name,
  service,
  status,
}: {
  time: string
  name: string
  service: string
  status: "scheduled" | "in-progress" | "completed"
}) {
  const statusColors = {
    scheduled: "bg-gray-100 text-gray-800",
    "in-progress": "bg-blue-100 text-blue-800",
    completed: "bg-green-100 text-green-800",
  }

  const statusLabels = {
    scheduled: "Scheduled",
    "in-progress": "In Progress",
    completed: "Completed",
  }

  return (
    <div className="flex items-center p-3 border rounded-lg">
      <div className="w-16 text-center">
        <p className="font-medium">{time}</p>
      </div>
      <div className="flex-1 ml-4">
        <p className="font-medium">{name}</p>
        <p className="text-sm text-muted-foreground">{service}</p>
      </div>
      <Badge variant="outline" className={statusColors[status]}>
        {statusLabels[status]}
      </Badge>
    </div>
  )
}

