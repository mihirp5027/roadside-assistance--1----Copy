"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  MapPin,
  Car,
  Phone,
  Shield,
  MessageSquare,
  Award,
  AlertTriangle,
  Navigation,
  Video,
  Droplet,
  Stethoscope,
  Bell,
} from "lucide-react";
import { mockServices, mockHistory, mockNotifications } from "@/lib/mock-data";

export default function Dashboard() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [unreadNotifications, setUnreadNotifications] = useState(0);

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem("user");
    if (!userData) {
      router.push("/auth/signin");
      return;
    }
    setUser(JSON.parse(userData));

    // Count unread notifications
    const unread = mockNotifications.filter(n => !n.read).length;
    setUnreadNotifications(unread);
  }, [router]);

  if (!user) {
    return null;
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b shadow-sm">
        <div className="container flex items-center justify-between h-16 px-4">
          <div className="flex items-center space-x-2">
            <Shield className="w-8 h-8 text-primary" />
            <h1 className="text-xl font-bold">RoadGuard</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="/notifications">
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="w-5 h-5" />
                {unreadNotifications > 0 && (
                  <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
                )}
              </Button>
            </Link>
            <Button variant="ghost" size="icon">
              <MessageSquare className="w-5 h-5" />
            </Button>
            <Link href="/profile">
              <div className="w-8 h-8 overflow-hidden rounded-full bg-primary">
                <img src="/placeholder.svg?height=32&width=32" alt="Profile" className="object-cover w-full h-full" />
              </div>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <div className="container px-4 py-6">
          {/* Location Bar */}
          <div className="flex items-center p-3 mb-6 bg-white rounded-lg shadow-sm">
            <MapPin className="w-5 h-5 mr-2 text-primary" />
            <div className="flex-1 text-sm">
              <p className="font-medium">Current Location</p>
              <p className="text-muted-foreground">123 Main Street, Anytown</p>
            </div>
            <Button variant="ghost" size="sm">
              Change
            </Button>
          </div>

          {/* SOS Button */}
          <div className="mb-6">
            <Link href="/emergency">
              <Button className="w-full py-6 text-lg font-bold bg-red-600 hover:bg-red-700">
                <AlertTriangle className="w-6 h-6 mr-2" />
                SOS EMERGENCY
              </Button>
            </Link>
          </div>

          {/* Services Tabs */}
          <Tabs defaultValue="services" className="mb-6">
            <TabsList className="w-full">
              <TabsTrigger value="services" className="flex-1">
                Services
              </TabsTrigger>
              <TabsTrigger value="nearby" className="flex-1">
                Nearby
              </TabsTrigger>
              <TabsTrigger value="history" className="flex-1">
                History
              </TabsTrigger>
            </TabsList>
            <TabsContent value="services" className="mt-4">
              <div className="grid grid-cols-2 gap-4">
                <ServiceCard
                  icon={<Car />}
                  title="Mechanic"
                  description="Find nearby mechanics"
                  href="/services/mechanic"
                />
                <ServiceCard
                  icon={<Navigation />}
                  title="Towing"
                  description="Request towing service"
                  href="/services/towing"
                />
                <ServiceCard
                  icon={<Droplet />}
                  title="Fuel Delivery"
                  description="Get fuel delivered"
                  href="/services/fuel"
                />
                <ServiceCard
                  icon={<Video />}
                  title="Video Consult"
                  description="Live mechanic consultation"
                  href="/services/video-consult"
                />
                <ServiceCard
                  icon={<Stethoscope />}
                  title="AR Diagnosis"
                  description="Self-diagnose with AR"
                  href="/services/ar-diagnosis"
                />
                <ServiceCard
                  icon={<Phone />}
                  title="Medical Help"
                  description="Emergency medical assistance"
                  href="/services/medical"
                />
              </div>
            </TabsContent>
            <TabsContent value="nearby">
              <div className="relative w-full h-[400px] bg-gray-100 rounded-lg overflow-hidden mb-4">
                <div className="absolute inset-0 flex items-center justify-center">
                  <p className="text-muted-foreground">Map view loading...</p>
                </div>
                <div className="absolute bottom-4 right-4">
                  <Button size="sm" className="shadow-md">
                    <MapPin className="w-4 h-4 mr-2" />
                    Recenter
                  </Button>
                </div>
              </div>
              <div className="space-y-3">
                {mockServices.map((service) => (
                  <NearbyServiceCard
                    key={service.id}
                    name={service.name}
                    type={service.type}
                    distance={service.distance}
                    rating={service.rating}
                    eta={service.eta}
                    href={`/services/${service.type}/${service.id}`}
                  />
                ))}
              </div>
            </TabsContent>
            <TabsContent value="history">
              <div className="space-y-4">
                {mockHistory.map((item) => (
                  <HistoryItem
                    key={item.id}
                    date={item.date}
                    service={item.service}
                    provider={item.provider}
                    status={item.status}
                    href={`/history/${item.id}`}
                  />
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* Bottom Navigation */}
      <nav className="sticky bottom-0 z-10 bg-white border-t">
        <div className="container grid h-16 grid-cols-4">
          <NavItem icon={<Car />} label="Home" active href="/dashboard" />
          <NavItem icon={<MapPin />} label="Map" href="/map" />
          <NavItem icon={<Award />} label="Rewards" href="/rewards" />
          <NavItem icon={<Shield />} label="Profile" href="/profile" />
        </div>
      </nav>
    </div>
  );
}

function ServiceCard({
  icon,
  title,
  description,
  href,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
  href: string;
}) {
  return (
    <Link href={href}>
      <Card className="overflow-hidden transition-all duration-200 hover:shadow-md">
        <div className="p-4">
          <div className="p-2 mb-3 rounded-full w-fit bg-primary/10">
            <div className="text-primary">{icon}</div>
          </div>
          <h3 className="font-medium">{title}</h3>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
      </Card>
    </Link>
  );
}

function NearbyServiceCard({
  name,
  type,
  distance,
  rating,
  eta,
  href,
}: {
  name: string;
  type: string;
  distance: string;
  rating: number;
  eta: string;
  href: string;
}) {
  return (
    <Link href={href}>
      <Card className="overflow-hidden transition-all duration-200 hover:shadow-md">
        <div className="p-4">
          <div className="flex items-start">
            <div className="w-12 h-12 mr-3 overflow-hidden rounded-lg bg-gray-100 flex items-center justify-center">
              {type === "mechanic" && <Car className="w-6 h-6 text-primary" />}
              {type === "towing" && <Navigation className="w-6 h-6 text-primary" />}
              {type === "fuel" && <Droplet className="w-6 h-6 text-primary" />}
            </div>
            <div className="flex-1">
              <h3 className="font-medium">{name}</h3>
              <div className="flex items-center mb-1">
                <span className="text-xs px-2 py-0.5 bg-primary/10 text-primary rounded-full mr-2 capitalize">{type}</span>
                <span className="text-xs text-muted-foreground">{distance}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <svg className="w-4 h-4 text-yellow-500 fill-current" viewBox="0 0 24 24">
                    <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                  </svg>
                  <span className="ml-1 text-sm font-medium">{rating}</span>
                </div>
                <span className="text-sm font-medium">ETA: {eta}</span>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </Link>
  );
}

function HistoryItem({
  date,
  service,
  provider,
  status,
  href,
}: {
  date: string;
  service: string;
  provider: string;
  status: string;
  href: string;
}) {
  return (
    <Link href={href}>
      <Card className="overflow-hidden transition-all duration-200 hover:shadow-md">
        <div className="p-4">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm font-medium text-muted-foreground">{date}</p>
            <span className="px-2 py-1 text-xs font-medium text-green-700 bg-green-100 rounded-full">{status}</span>
          </div>
          <h3 className="font-medium">{service}</h3>
          <p className="text-sm text-muted-foreground">{provider}</p>
        </div>
      </Card>
    </Link>
  );
}

function NavItem({
  icon,
  label,
  active = false,
  href,
}: {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  href: string;
}) {
  return (
    <Link href={href} className="flex items-center justify-center">
      <div className={`flex flex-col items-center justify-center ${active ? "text-primary" : "text-muted-foreground"}`}>
        <div>{icon}</div>
        <span className="text-xs">{label}</span>
      </div>
    </Link>
  );
} 