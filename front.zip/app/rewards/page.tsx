import type React from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import { ArrowLeft, Award, Gift, Star, Clock, Ticket, Percent, Shield } from "lucide-react"

export default function RewardsPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b shadow-sm">
        <div className="container flex items-center h-16 px-4">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="w-6 h-6" />
            </Button>
          </Link>
          <h1 className="ml-4 text-xl font-bold">Rewards & Loyalty</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <div className="container px-4 py-6">
          {/* Rewards Status */}
          <Card className="mb-6 overflow-hidden">
            <div className="p-6 text-white bg-gradient-to-r from-primary to-primary/80">
              <div className="flex items-center mb-4">
                <div className="p-2 mr-3 rounded-full bg-white/20">
                  <Award className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-xl font-bold">Silver Member</h2>
                  <p className="text-sm text-white/80">Since January 2023</p>
                </div>
              </div>

              <div className="mb-2">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm">350 points</span>
                  <span className="text-sm">Gold (1000 points)</span>
                </div>
                <Progress value={35} className="h-2 bg-white/20" />
              </div>

              <p className="text-sm text-white/80">Earn 650 more points to reach Gold status</p>
            </div>

            <div className="p-4 bg-white">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Available Points</h3>
                  <p className="text-2xl font-bold">350</p>
                </div>
                <Button>Redeem Points</Button>
              </div>
            </div>
          </Card>

          {/* Rewards Tabs */}
          <Tabs defaultValue="rewards" className="mb-6">
            <TabsList className="w-full">
              <TabsTrigger value="rewards" className="flex-1">
                Rewards
              </TabsTrigger>
              <TabsTrigger value="history" className="flex-1">
                History
              </TabsTrigger>
              <TabsTrigger value="tiers" className="flex-1">
                Tiers
              </TabsTrigger>
            </TabsList>

            <TabsContent value="rewards" className="mt-4">
              <div className="space-y-4">
                <h3 className="font-medium">Available Rewards</h3>

                <RewardCard
                  icon={<Percent />}
                  title="15% Off Next Service"
                  description="Get 15% off your next roadside assistance service"
                  points={200}
                />

                <RewardCard
                  icon={<Gift />}
                  title="Free Tire Inspection"
                  description="Complimentary tire inspection at partner locations"
                  points={150}
                />

                <RewardCard
                  icon={<Ticket />}
                  title="Priority Service"
                  description="Skip the queue for your next service request"
                  points={300}
                />

                <RewardCard
                  icon={<Shield />}
                  title="Extended Coverage"
                  description="Add an extra 10 miles to your towing coverage"
                  points={400}
                  disabled
                />
              </div>
            </TabsContent>

            <TabsContent value="history">
              <div className="space-y-4">
                <h3 className="font-medium">Points History</h3>

                <HistoryItem title="Emergency Towing Service" date="May 15, 2023" points="+100" isEarned />

                <HistoryItem title="Redeemed: 10% Discount" date="April 22, 2023" points="-150" isEarned={false} />

                <HistoryItem title="Flat Tire Assistance" date="March 10, 2023" points="+75" isEarned />

                <HistoryItem title="Referral Bonus: John Smith" date="February 5, 2023" points="+200" isEarned />
              </div>
            </TabsContent>

            <TabsContent value="tiers">
              <div className="space-y-4">
                <h3 className="font-medium">Membership Tiers</h3>

                <TierCard
                  title="Bronze"
                  points="0 - 499 points"
                  benefits={["Basic roadside assistance", "Standard response times", "Access to partner discounts"]}
                  current={false}
                />

                <TierCard
                  title="Silver"
                  points="500 - 999 points"
                  benefits={[
                    "All Bronze benefits",
                    "10% discount on services",
                    "Faster response times",
                    "Quarterly bonus points",
                  ]}
                  current={true}
                />

                <TierCard
                  title="Gold"
                  points="1000+ points"
                  benefits={[
                    "All Silver benefits",
                    "20% discount on services",
                    "Priority emergency response",
                    "Free annual vehicle check-up",
                    "Exclusive partner offers",
                  ]}
                  current={false}
                />
              </div>
            </TabsContent>
          </Tabs>

          {/* How to Earn */}
          <Card className="mb-6">
            <div className="p-4">
              <h3 className="mb-3 font-medium">How to Earn Points</h3>

              <div className="space-y-3">
                <EarnMethod
                  icon={<Star />}
                  title="Use Our Services"
                  description="Earn points every time you use roadside assistance"
                  points="+50-100 points"
                />

                <EarnMethod
                  icon={<Gift />}
                  title="Refer Friends"
                  description="Get points when friends sign up with your code"
                  points="+200 points"
                />

                <EarnMethod
                  icon={<Clock />}
                  title="Annual Renewal"
                  description="Renew your membership annually"
                  points="+150 points"
                />
              </div>
            </div>
          </Card>
        </div>
      </main>

      {/* Bottom Navigation */}
      <nav className="sticky bottom-0 z-10 bg-white border-t">
        <div className="container grid h-16 grid-cols-4">
          <NavItem icon={<Shield />} label="Home" />
          <NavItem icon={<Star />} label="Services" />
          <NavItem icon={<Award />} label="Rewards" active />
          <NavItem icon={<Gift />} label="Profile" />
        </div>
      </nav>
    </div>
  )
}

function RewardCard({
  icon,
  title,
  description,
  points,
  disabled = false,
}: {
  icon: React.ReactNode
  title: string
  description: string
  points: number
  disabled?: boolean
}) {
  return (
    <Card className={`overflow-hidden ${disabled ? "opacity-60" : ""}`}>
      <div className="p-4">
        <div className="flex items-start">
          <div className="p-2 mr-3 rounded-full bg-primary/10">
            <div className="text-primary">{icon}</div>
          </div>
          <div className="flex-1">
            <h4 className="font-medium">{title}</h4>
            <p className="mb-2 text-sm text-muted-foreground">{description}</p>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Star className="w-4 h-4 mr-1 text-amber-500 fill-amber-500" />
                <span className="font-medium">{points} points</span>
              </div>
              <Button size="sm" disabled={disabled}>
                {disabled ? "Not Enough Points" : "Redeem"}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </Card>
  )
}

function HistoryItem({
  title,
  date,
  points,
  isEarned,
}: {
  title: string
  date: string
  points: string
  isEarned: boolean
}) {
  return (
    <Card className="overflow-hidden">
      <div className="p-4">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-medium">{title}</h4>
            <p className="text-sm text-muted-foreground">{date}</p>
          </div>
          <span className={`font-bold ${isEarned ? "text-green-600" : "text-red-600"}`}>{points}</span>
        </div>
      </div>
    </Card>
  )
}

function TierCard({
  title,
  points,
  benefits,
  current = false,
}: {
  title: string
  points: string
  benefits: string[]
  current?: boolean
}) {
  return (
    <Card className={`overflow-hidden ${current ? "border-primary" : ""}`}>
      <div className="p-4">
        <div className="flex items-center justify-between mb-2">
          <h4 className="text-lg font-medium">{title}</h4>
          {current && (
            <span className="px-2 py-1 text-xs font-medium text-white rounded-full bg-primary">Current Tier</span>
          )}
        </div>
        <p className="mb-3 text-sm text-muted-foreground">{points}</p>

        <h5 className="mb-2 text-sm font-medium">Benefits:</h5>
        <ul className="pl-5 mb-2 space-y-1 text-sm list-disc">
          {benefits.map((benefit, index) => (
            <li key={index}>{benefit}</li>
          ))}
        </ul>
      </div>
    </Card>
  )
}

function EarnMethod({
  icon,
  title,
  description,
  points,
}: {
  icon: React.ReactNode
  title: string
  description: string
  points: string
}) {
  return (
    <div className="flex items-start p-3 rounded-lg bg-gray-50">
      <div className="p-2 mr-3 rounded-full bg-primary/10">
        <div className="text-primary">{icon}</div>
      </div>
      <div className="flex-1">
        <h4 className="font-medium">{title}</h4>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
      <div className="text-sm font-medium text-primary">{points}</div>
    </div>
  )
}

function NavItem({
  icon,
  label,
  active = false,
}: {
  icon: React.ReactNode
  label: string
  active?: boolean
}) {
  return (
    <div className={`flex flex-col items-center justify-center ${active ? "text-primary" : "text-muted-foreground"}`}>
      <div>{icon}</div>
      <span className="text-xs">{label}</span>
    </div>
  )
}

