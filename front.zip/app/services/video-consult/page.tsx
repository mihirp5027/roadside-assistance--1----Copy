import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import { ArrowLeft, Video, Star, Clock, MessageSquare, Phone, MicOff, VideoOff, User } from "lucide-react"

export default function VideoConsultPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b shadow-sm">
        <div className="container flex items-center h-16 px-4">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="w-6 h-6" />
            </Button>
          </Link>
          <h1 className="ml-4 text-xl font-bold">Video Consultation</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <div className="container px-4 py-6">
          {/* Video Call Preview */}
          <Card className="overflow-hidden mb-6">
            <div className="relative aspect-video bg-gray-900">
              <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
                <Video className="w-12 h-12 mb-2 opacity-50" />
                <p className="text-sm opacity-70">Video call will appear here</p>
              </div>

              {/* Small Self-View */}
              <div className="absolute bottom-4 right-4 w-1/4 aspect-video bg-gray-800 rounded-lg border border-gray-700 flex items-center justify-center">
                <User className="w-8 h-8 opacity-50 text-white" />
              </div>
            </div>

            {/* Call Controls */}
            <div className="flex items-center justify-center p-4 bg-white gap-4">
              <Button variant="outline" size="icon" className="rounded-full w-12 h-12">
                <MicOff className="w-5 h-5" />
              </Button>
              <Button variant="destructive" size="icon" className="rounded-full w-14 h-14">
                <Phone className="w-6 h-6 rotate-135" />
              </Button>
              <Button variant="outline" size="icon" className="rounded-full w-12 h-12">
                <VideoOff className="w-5 h-5" />
              </Button>
            </div>
          </Card>

          {/* Mechanic Info */}
          <Card className="mb-6">
            <div className="p-4">
              <div className="flex items-start">
                <div className="w-16 h-16 mr-4 overflow-hidden rounded-full bg-gray-100">
                  <img
                    src="/placeholder.svg?height=64&width=64"
                    alt="Mechanic"
                    className="object-cover w-full h-full"
                  />
                </div>
                <div>
                  <h3 className="font-medium">Mike Johnson</h3>
                  <div className="flex items-center mb-1">
                    <Star className="w-4 h-4 mr-1 text-yellow-500 fill-yellow-500" />
                    <span className="text-sm font-medium">4.9</span>
                    <span className="mx-1 text-sm text-muted-foreground">(128 reviews)</span>
                  </div>
                  <p className="text-sm text-muted-foreground">Certified Mechanic • 8 years exp.</p>
                  <div className="flex items-center mt-1">
                    <Clock className="w-4 h-4 mr-1 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Call duration: 00:03:45</span>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* Consultation Tabs */}
          <Tabs defaultValue="notes" className="mb-6">
            <TabsList className="w-full">
              <TabsTrigger value="notes" className="flex-1">
                Notes
              </TabsTrigger>
              <TabsTrigger value="diagnosis" className="flex-1">
                Diagnosis
              </TabsTrigger>
              <TabsTrigger value="share" className="flex-1">
                Share
              </TabsTrigger>
            </TabsList>
            <TabsContent value="notes" className="mt-4">
              <Card className="p-4">
                <h3 className="mb-3 font-medium">Consultation Notes</h3>
                <div className="space-y-3">
                  <NoteItem
                    time="2:30 PM"
                    note="Customer reported engine making unusual knocking sound when accelerating."
                  />
                  <NoteItem time="2:32 PM" note="Requested customer to show engine bay via video." highlight />
                  <NoteItem
                    time="2:35 PM"
                    note="Identified potential issue with timing belt. Recommended immediate service to prevent further damage."
                  />
                </div>
                <div className="flex items-center mt-4 p-3 rounded-lg border">
                  <input type="text" placeholder="Add a note..." className="flex-1 bg-transparent outline-none" />
                  <Button size="sm">Add</Button>
                </div>
              </Card>
            </TabsContent>
            <TabsContent value="diagnosis">
              <Card className="p-4">
                <h3 className="mb-3 font-medium">Preliminary Diagnosis</h3>
                <div className="p-3 mb-3 rounded-lg bg-amber-50 border border-amber-200">
                  <h4 className="text-sm font-medium text-amber-800">Timing Belt Issue</h4>
                  <p className="text-sm text-amber-700">
                    Based on the symptoms and visual inspection, there appears to be wear on the timing belt. This
                    requires immediate attention to prevent engine damage.
                  </p>
                </div>

                <div className="space-y-3">
                  <DiagnosisItem title="Severity" value="High" color="red" />
                  <DiagnosisItem title="Estimated Repair Cost" value="$350 - $500" color="amber" />
                  <DiagnosisItem title="Recommended Action" value="Visit mechanic within 24 hours" color="blue" />
                </div>

                <Button className="w-full mt-4">Find Nearby Mechanics</Button>
              </Card>
            </TabsContent>
            <TabsContent value="share">
              <Card className="p-4">
                <h3 className="mb-3 font-medium">Share Consultation</h3>
                <p className="mb-4 text-sm text-muted-foreground">
                  Share this consultation with your mechanic or save it for your records.
                </p>

                <div className="space-y-3">
                  <Button variant="outline" className="w-full justify-start">
                    <MessageSquare className="w-5 h-5 mr-2" />
                    Share via Message
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Video className="w-5 h-5 mr-2" />
                    Save Recording
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Star className="w-5 h-5 mr-2" />
                    Rate Consultation
                  </Button>
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}

function NoteItem({
  time,
  note,
  highlight = false,
}: {
  time: string
  note: string
  highlight?: boolean
}) {
  return (
    <div className={`p-3 rounded-lg ${highlight ? "bg-primary/10" : "bg-gray-50"}`}>
      <div className="flex items-start">
        <p className="w-16 text-xs font-medium text-muted-foreground">{time}</p>
        <p className={`flex-1 text-sm ${highlight ? "font-medium" : ""}`}>{note}</p>
      </div>
    </div>
  )
}

function DiagnosisItem({
  title,
  value,
  color,
}: {
  title: string
  value: string
  color: "red" | "amber" | "blue" | "green"
}) {
  const colorClasses = {
    red: "bg-red-50 border-red-200 text-red-700",
    amber: "bg-amber-50 border-amber-200 text-amber-700",
    blue: "bg-blue-50 border-blue-200 text-blue-700",
    green: "bg-green-50 border-green-200 text-green-700",
  }

  return (
    <div className={`p-3 rounded-lg border ${colorClasses[color]}`}>
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-medium">{title}</h4>
        <p className="text-sm font-bold">{value}</p>
      </div>
    </div>
  )
}

