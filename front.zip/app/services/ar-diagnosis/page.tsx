import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import Link from "next/link"
import { ArrowLeft, Camera, Info, Lightbulb, MessageSquare, Stethoscope, CheckCircle, ChevronRight } from "lucide-react"

export default function ARDiagnosisPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b shadow-sm">
        <div className="container flex items-center h-16 px-4">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="w-6 h-6" />
            </Button>
          </Link>
          <h1 className="ml-4 text-xl font-bold">AR Self-Diagnosis</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <div className="container px-4 py-6">
          {/* AR Camera View */}
          <Card className="overflow-hidden mb-6">
            <div className="relative aspect-[4/3] bg-gray-900">
              <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
                <Camera className="w-12 h-12 mb-2 opacity-50" />
                <p className="text-sm opacity-70">Camera preview will appear here</p>
              </div>

              {/* AR Overlay Elements */}
              <div className="absolute top-4 right-4">
                <Button variant="secondary" size="sm" className="bg-black/50 text-white hover:bg-black/70">
                  <Lightbulb className="w-4 h-4 mr-1" />
                  Flashlight
                </Button>
              </div>

              <div className="absolute bottom-4 left-0 right-0 flex justify-center">
                <Button className="rounded-full w-16 h-16 flex items-center justify-center">
                  <Camera className="w-8 h-8" />
                </Button>
              </div>
            </div>

            <div className="p-4 bg-white">
              <div className="flex items-center mb-2">
                <Stethoscope className="w-5 h-5 mr-2 text-primary" />
                <h3 className="font-medium">Point camera at your vehicle issue</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                Our AI will analyze the image and provide diagnostic information and repair guidance.
              </p>
            </div>
          </Card>

          {/* Diagnosis Instructions */}
          <Card className="mb-6">
            <div className="p-4">
              <h3 className="mb-3 font-medium">How to use AR Diagnosis</h3>

              <div className="space-y-3">
                <InstructionStep
                  number={1}
                  title="Point your camera"
                  description="Aim your camera at the problematic area of your vehicle"
                />
                <InstructionStep
                  number={2}
                  title="Follow AR guides"
                  description="The app will overlay diagnostic information on your screen"
                />
                <InstructionStep
                  number={3}
                  title="Get repair instructions"
                  description="Follow step-by-step guidance for simple repairs"
                />
              </div>
            </div>
          </Card>

          {/* Common Issues */}
          <h3 className="mb-3 font-medium">Common Issues</h3>
          <div className="grid grid-cols-1 gap-3 mb-6">
            <IssueCard title="Flat Tire" description="Learn how to change a flat tire safely" completed={true} />
            <IssueCard title="Dead Battery" description="Diagnose battery issues and jump-start procedures" />
            <IssueCard title="Engine Overheating" description="Identify cooling system problems and safe solutions" />
            <IssueCard title="Check Engine Light" description="Scan and interpret diagnostic trouble codes" />
          </div>

          {/* Expert Help */}
          <Card className="bg-primary/5 border-primary/20 mb-6">
            <div className="p-4">
              <div className="flex items-start">
                <div className="p-2 mr-3 rounded-full bg-primary/10">
                  <MessageSquare className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Need expert help?</h3>
                  <p className="mb-3 text-sm text-muted-foreground">
                    Connect with a certified mechanic via live video consultation
                  </p>
                  <Button>Start Video Consultation</Button>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </main>

      {/* AI Assistant */}
      <div className="fixed bottom-4 right-4">
        <Button className="w-12 h-12 rounded-full shadow-lg" size="icon">
          <MessageSquare className="w-6 h-6" />
        </Button>
      </div>
    </div>
  )
}

function InstructionStep({
  number,
  title,
  description,
}: {
  number: number
  title: string
  description: string
}) {
  return (
    <div className="flex items-start">
      <div className="flex items-center justify-center w-8 h-8 mr-3 text-white rounded-full bg-primary">{number}</div>
      <div>
        <h4 className="font-medium">{title}</h4>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </div>
  )
}

function IssueCard({
  title,
  description,
  completed = false,
}: {
  title: string
  description: string
  completed?: boolean
}) {
  return (
    <Card className="overflow-hidden">
      <div className="flex items-center p-4">
        <div className={`p-2 mr-3 rounded-full ${completed ? "bg-green-100" : "bg-gray-100"}`}>
          {completed ? <CheckCircle className="w-5 h-5 text-green-600" /> : <Info className="w-5 h-5 text-gray-500" />}
        </div>
        <div className="flex-1">
          <h4 className="font-medium">{title}</h4>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
        <ChevronRight className="w-5 h-5 text-muted-foreground" />
      </div>
    </Card>
  )
}

